def main():
    print("Hello from rat-vml!")


if __name__ == "__main__":
    main()
